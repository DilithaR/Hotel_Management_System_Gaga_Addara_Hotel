
     $(document).ready(function () {
         $('.dropBtn1').click(function () {
             $('nav ul .dropCont1').toggleClass('show');
             $('nav ul .first-sp').toggleClass('rotate');
         });
     });


 $(document).ready(function () {
     $('.dropBtn2').click(function () {
         $('nav ul .dropCont2').toggleClass('show');
         $('nav ul .secound-sp').toggleClass('rotate');
     });
 });


 $(document).ready(function () {
     $('.dropBtnReport').click(function () {
         $('nav ul .dropContReport').toggleClass('show');
         $('nav ul .Report-sp').toggleClass('rotate');
     });
 });

  $(document).ready(function () {
      $('.dropbtnRooms').click(function () {
          $('nav ul .dropContRooms').toggleClass('show');
          $('nav ul .rooms-sp').toggleClass('rotate');
      });
  });

   $(document).ready(function () {
       $('.dropbtnHalls').click(function () {
           $('nav ul .dropContHalls').toggleClass('show');
           $('nav ul .Halls-sp').toggleClass('rotate');
       });
   });

    $(document).ready(function () {
        $('.dropBtnMenu').click(function () {
            $('nav ul .dropContMenu').toggleClass('show');
            $('nav ul .Menu-sp').toggleClass('rotate');
        });
    });
	
	$(document).ready(function () {
        $('.dropBtnPayment').click(function () {
            $('nav ul .dropContPayment').toggleClass('show');
            $('nav ul .Payment-sp').toggleClass('rotate');
        });
    });



